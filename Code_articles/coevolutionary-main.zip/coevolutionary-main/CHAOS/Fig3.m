n=200;
CAOz(RRG(n,8),SRW(RRG(n,4)),.5,.1,0.001,20,[1 -ones(1,n-1)],[1 -ones(1,n-1)],4*n^2,1);
CAOz(RRG(n,8),SRW(RRG(n,4)),.5,.1,0.01,20,[1 -ones(1,n-1)],[1 -ones(1,n-1)],4*n^2,1);
CAOz(RRG(n,8),SRW(RRG(n,4)),.5,.5,0.001,20,[1 -ones(1,n-1)],[1 -ones(1,n-1)],4*n^2,1);