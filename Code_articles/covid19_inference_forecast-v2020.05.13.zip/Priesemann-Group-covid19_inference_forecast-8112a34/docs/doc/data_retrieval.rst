
.. warning::

    Important: This is the documentation of code no longer in active development.
    This is the link to the current docs: `covid19-inference <https://covid19-inference.readthedocs.io/en/latest/doc/gettingstarted.html>`_

Data Retrieval
==============

.. automodule:: covid19_inference.data_retrieval
    :members: get_jhu_confirmed_cases, get_jhu_deaths, get_last_date, filter_one_country