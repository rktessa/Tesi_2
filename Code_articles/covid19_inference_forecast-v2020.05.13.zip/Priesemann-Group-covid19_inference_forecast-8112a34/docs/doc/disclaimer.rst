.. warning::

    Important: This is the documentation of code no longer in active development.
    This is the link to the current docs: `covid19-inference <https://covid19-inference.readthedocs.io/en/latest/doc/gettingstarted.html>`_


.. mdinclude:: ../../DISCLAIMER.md
