.. warning::

    Important: This is the documentation of code no longer in active development.
    This is the link to the current docs: `covid19-inference <https://covid19-inference.readthedocs.io/en/latest/doc/gettingstarted.html>`_


Models
======

.. automodule:: covid19_inference
    :members: SIR_with_change_points, SEIR_with_extensions, _SIR_model, _SEIR_model_with_delay