# Map generation scripts 
## Script_1
### Description:
### Input:
### Output: 
